import tkinter as tk
from tkinter import *
import webbrowser
import tkinter
import sys
import os
from tkinter.filedialog import askopenfilename

root = tk.Tk()


text2 = tk.Text(root, height=27, width=23)
scroll = tk.Scrollbar(root, command=text2.yview)
text2.configure(yscrollcommand=scroll.set)
text2.tag_configure('bold_italics', font=('Arial', 12, 'bold', 'italic'))
text2.tag_configure('big', font=('Verdana', 18, 'bold'))
text2.tag_configure('color',
                    foreground='#476042',
                    font=('Times New Roman', 13 ))
text2.tag_bind('follow',
               '<1>',
               lambda e, t=text2: t.insert(tk.END, "Not now, maybe later!"))
text2.insert(tk.END,' OSINT TEAM\n', 'big')
quote = """
    Project Manager : 
    James Dumitru

    Software Developers :
    Kenton Fong  
    Raymond Ezekiel
    Mahmood Mehrjoo

    Analysts : 
    Mohammad Salehi
    Nikhil Mohanty

"""
text2.insert(tk.END, quote, 'color')
text2.insert(tk.END, '\n', 'follow')
text2.pack(side=tk.LEFT)
label = tkinter.Label(root, text = "").pack()
scroll.pack(side=tk.RIGHT, fill=tk.Y)
photo = tk.PhotoImage(file='./3.gif')
text2.image_create(tk.END, image=photo)
new = 1
url = "https://drive.google.com/file/d/1KwGPHRQSghZfBOowcYKYgyhf90xLzo34/view?usp=sharing"
url1 = "https://drive.google.com/file/d/1RFXjeTF1lU8T4YkUFxfvv7fZjPKOl90r/view?usp=sharing"
url2 = "https://drive.google.com/file/d/1JwUXAHuQuj4MLvQYNV9KwtKTGMsFJo4Y/view?usp=sharing"
url3 = "https://drive.google.com/file/d/18B8LDknR6rCGlTj7-GlhSCEaNBDu5YGI/view?usp=sharing"
url4= "https://drive.google.com/file/d/1tD3v6PhjLIC7tmSCxx47aZa5mDTokWJf/view?usp=sharing"
url5= r"5.gif"
url6 = "https://github.com/tweepy/tweepy"
url7 = "https://pypi.org/project/python-facebook-api/"
url8 = "https://drive.google.com/drive/u/1/folders/0AHOeISC73oDMUk9PVA"
url9 = r"9.gif"
url10 = "https://docs.google.com/presentation/d/1THSeWHdyU0unvSNowGH4Pz2j9bh9flUBDwcco2NZb1o/edit#slide=id.g8464fc11cb_3_0"
url11 = "https://drive.google.com/file/d/1MXRaTsnFCoS29H29cg77NqaYFNijsO5B/view?usp=sharing"

root.title("IIT DASHBOARD")


top_frame = tkinter.Frame(root).pack()
label = tkinter.Label(root, text = "HAWK - OSINT - Dashboard ", fg = "RED").pack()
 

label = tkinter.Label(root, text = "").pack()



def openweb():
    webbrowser.open(url,new=new)
Btn = Button(top_frame, text = "TWITTER API Elon Musk Username", fg= "white", bg="green", command=openweb)
Btn.pack(padx=10, pady=1, ipadx=78)

def openweb1():
    webbrowser.open(url1)
Btn = Button(top_frame , text = "TWITTER API COVID 19 #", fg = "white", bg="green", command= openweb1)
Btn.pack(padx=10, pady=1, ipadx=107)

def openweb2():
    webbrowser.open(url2)
Btn = Button(top_frame , text = "TWITTER API Chicago Location ", fg = "white", bg="green", command= openweb2)
Btn.pack(padx=10, pady=1, ipadx=88)

def openweb3():
    webbrowser.open(url3)
Btn = Button(top_frame , text = "TWITTER API Cybersecurity #", fg = "white", bg="green", command= openweb3)
Btn.pack(padx=10, pady=1, ipadx=92)

def openweb4():
    webbrowser.open(url4)
Btn = Button(top_frame , text = "TWITTER API Election2020 #", fg = "white", bg="green", command= openweb4)
Btn.pack(padx=10, pady=1, ipadx=95)



label = tkinter.Label(root, text = "").pack()

def openweb5():
    webbrowser.open(url5)
Btn1 = Button(top_frame , text = "Web API for Programmers ", fg = "white", bg="blue", command= openweb5)
Btn1.pack(padx=10, pady=1, ipadx=98)

def openweb6():
    webbrowser.open(url6)

Btn1 = Button(top_frame , text = "Tweepy Python Source", fg = "white", bg="blue", command= openweb6)
Btn1.pack(padx=10, pady=1, ipadx=110)

def openweb7():
    webbrowser.open(url7)
Btn1 = Button(top_frame , text = "Other Sources", fg = "white", bg="blue", command= openweb7)
Btn1.pack(padx=10, pady=1, ipadx=138)

label = tkinter.Label(root, text = "").pack()


def openweb9():
    webbrowser.open(url9)
Btn2 = Button(top_frame , text = "Group Agenda", fg = "white", bg="red", command= openweb9)
Btn2.pack(padx=10, pady=1, ipadx=138)


def openweb8():
    webbrowser.open(url8)
Btn2 = Button(top_frame , text = "ITM 448-548 Final Assigment", fg = "white", bg="red", command= openweb8)
Btn2.pack(padx=10, pady=1, ipadx=89)


def openweb10():
    webbrowser.open(url10)
Btn2 = Button(top_frame , text = "Presentation", fg = "white", bg="red", command= openweb10)
Btn2.pack(padx=10, pady=1, ipadx=143)


def openweb11():
    webbrowser.open(url11)
Btn2 = Button(top_frame , text = "Rapid Minor Export", fg = "white", bg="red", command= openweb11)
Btn2.pack(padx=10, pady=1, ipadx=123)

label = tkinter.Label(root, text = "").pack()
label = tkinter.Label(root, text = "Thank You Professor Dawson").pack()
label = tkinter.Label(root, text = "").pack()

root.mainloop()